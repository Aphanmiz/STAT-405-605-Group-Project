#!/usr/bin/Rscript

library(shiny)
runApp("app", launch.browser=TRUE)

